import { useState, useEffect, useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";

/*
 * ═══════════════════════════════════════════════════════════════════════════════
 * ÁRBOL DE GOLPES
 * ═══════════════════════════════════════════════════════════════════════════════
 */
const GTREE = {
  Saque:    { c:"#eab308", s1:["1er Servicio","2do Servicio"], s2:{}, grupo:"inicio" },
  Resto:    { c:"#2563eb", s1:["Directo","Globo","Con pared"],  s2:{"Directo":["Derecha","Revés"],"Globo":["Derecha","Revés"],"Con pared":["Lateral","Fondo","Fondo→Lateral","Lateral→Fondo","Reja"]}, grupo:"inicio" },
  Directo:       { c:"#f97316", s1:["Derecha","Revés"], s2:{}, grupo:"directos" },
  Sobrepique:    { c:"#f97316", s1:["Derecha","Revés"], s2:{}, grupo:"directos" },
  Chiquita:      { c:"#8b5cf6", s1:["Derecha","Revés"], s2:{}, grupo:"directos" },
  Globo:         { c:"#8b5cf6", s1:["Derecha","Revés"], s2:{}, grupo:"directos" },
  Contrapared:   { c:"#f97316", s1:["Derecha","Revés"], s2:{}, grupo:"directos" },
  Volea:         { c:"#10b981", s1:["Derecha","Revés"], s2:{}, grupo:"aereo" },
  Bandeja:       { c:"#10b981", s1:[], s2:{}, grupo:"aereo" },
  Víbora:        { c:"#10b981", s1:[], s2:{}, grupo:"aereo" },
  Rulo:          { c:"#10b981", s1:[], s2:{}, grupo:"aereo" },
  Gancho:        { c:"#10b981", s1:[], s2:{}, grupo:"aereo" },
  Smash:         { c:"#eab308", s1:["x3","x4","Que vuelve","A la reja","Rápido","Que se queda"], s2:{}, grupo:"smash" },
  "Salida de Pared": { c:"#f97316", s1:["Fondo→Lateral","Lateral→Fondo","Lateral","Fondo"], s2:{"Fondo→Lateral":["Globo","Chiquita","Directo"],"Lateral→Fondo":["Globo","Chiquita","Directo"],"Lateral":["Globo","Chiquita","Directo"],"Fondo":["Globo","Chiquita","Directo"]}, s3:{"Globo":["Derecha","Revés"],"Directo":["Derecha","Revés"],"Chiquita":[]}, grupo:"pared" },
  "Bajada de Pared": { c:"#f97316", s1:["Fondo→Lateral","Lateral→Fondo","Lateral","Fondo"], s2:{"Fondo→Lateral":["Globo","Chiquita","Directo"],"Lateral→Fondo":["Globo","Chiquita","Directo"],"Lateral":["Globo","Chiquita","Directo"],"Fondo":["Globo","Chiquita","Directo"]}, s3:{"Globo":["Derecha","Revés"],"Directo":["Derecha","Revés"],"Chiquita":[]}, grupo:"pared" },
};

const GRUPOS_SIN_PARED = [
  { label:"🧱 DIRECTO/SOBREPIQUE", keys:["Directo","Sobrepique","Chiquita","Globo","Contrapared"], c:"#f97316" },
  { label:"🏔 JUEGO AÉREO", keys:["Volea","Bandeja","Víbora","Rulo","Gancho"], c:"#10b981" },
];
const GRUPO_SMASH = { label:"💥 SMASH", keys:["Smash"], c:"#eab308" };
const GRUPOS_PARED = [
  { label:"🧱 GOLPES DE PARED", keys:["Salida de Pared","Bajada de Pared","Globo","Chiquita","Contrapared"], c:"#f97316" },
];

const PAREDES_OPCIONES = ["Sin pared","Fondo","Lateral","Fondo→Lateral","Lateral→Fondo","Reja"];

const CONS = [
  { k:"Winner",           l:"🏆 Winner",          c:"#059669", bg:"#d1fae5", b:"#10b981",
    sub:["Doble pique","Fuera de cancha","Vuelta al campo propio"] },
  { k:"Error No Forzado", l:"⚠️ Error NF",         c:"#dc2626", bg:"#fee2e2", b:"#ef4444",
    sub:["Red","Fuera","Larga","Ancha"] },
  { k:"Error Forzado",    l:"💢 Error Forzado",    c:"#ea580c", bg:"#ffedd5", b:"#f97316",
    sub:["Red","Fuera","Larga","Ancha"] },
  { k:"Continúa",         l:"↩️ Continúa",          c:"#2563eb", bg:"#dbeafe", b:"#3b82f6", sub:[] },
];

const PROFS = [{id:"FONDO",s:"Fdo"},{id:"MED_FONDO",s:"MF"},{id:"MED_RED",s:"MR"},{id:"RED",s:"Red"}];
const PROFO = [{id:"RED",s:"Red"},{id:"MED_RED",s:"MR"},{id:"MED_FONDO",s:"MF"},{id:"FONDO",s:"Fdo"}];
const LATS  = [
  {id:"EXT_IZQ",s:"PI",r:"drv",p:"rev"},{id:"IZQ_2",s:"I2",r:"drv",p:"rev"},{id:"IZQ_1",s:"I1",r:"drv",p:"rev"},
  {id:"CENTRO_IZQ",s:"CI",r:"drv",p:"rev"},{id:"CENTRO",s:"C",r:"ctr",p:"ctr"},{id:"CENTRO_DER",s:"CD",r:"rev",p:"drv"},
  {id:"DER_1",s:"D1",r:"rev",p:"drv"},{id:"DER_2",s:"D2",r:"rev",p:"drv"},{id:"EXT_DER",s:"PD",r:"rev",p:"drv"},
];

const DEF_J=[{id:1,n:"Jugador A1",eq:"A",l:"Drive"},{id:2,n:"Jugador A2",eq:"A",l:"Revés"},{id:3,n:"Rival B1",eq:"B",l:"Drive"},{id:4,n:"Rival B2",eq:"B",l:"Revés"}];
const INIT_SC={sets:{A:0,B:0},games:{A:0,B:0},points:{A:0,B:0}};
const PM={0:"0",1:"15",2:"30",3:"40"};

const SC=s=>s==="drv"?"#ea580c":s==="rev"?"#2563eb":"#94a3b8";
const HC=i=>{if(!i||i<0.01)return"#e2e8f0";const h=Math.round(120-i*120),s=60+i*20,l=80-i*30;return`hsla(${h},${s}%,${l}%,0.9)`;};
const HB=i=>i<0.01?"#cbd5e1":`hsla(${Math.round(120-i*120)},50%,60%,0.6)`;
const SL=g=>[g.tipo,g.s1,g.s2,g.s3].filter(Boolean).join("·");
const PCT=(w,n)=>n>0?Math.round(w/n*100):0;
const FD=ts=>new Date(ts).toLocaleDateString("es-AR",{day:"2-digit",month:"2-digit",year:"2-digit",hour:"2-digit",minute:"2-digit"});
function ZN(zid){if(!zid)return"";const c=zid.replace("ORI-","");const p=[...PROFS,...PROFO].find(x=>c.startsWith(x.id));const l=LATS.find(x=>c.endsWith(x.id));return`${p?.s||"?"}·${l?.s||"?"}`;}
function SAP(sc,eq){const s=JSON.parse(JSON.stringify(sc));const{points:pt,games:g,sets}=s;if(pt.A===3&&pt.B===3){g[eq]++;pt.A=0;pt.B=0;}else if(pt[eq]===3){g[eq]++;pt.A=0;pt.B=0;}else pt[eq]++;if((g.A>=6&&g.A-g.B>=2)||(g.A===7&&g.B===6)){sets.A++;g.A=0;g.B=0;}else if((g.B>=6&&g.B-g.A>=2)||(g.B===7&&g.A===6)){sets.B++;g.A=0;g.B=0;}return s;}

// ─── STORAGE — usa localStorage (funciona offline) ───────────────────────────
const db={
  get:async k=>{try{const r=localStorage.getItem(k);return r?JSON.parse(r):null;}catch{return null;}},
  set:async(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));}catch{}},
};

function calcSt(gs){const P={};gs.forEach(g=>{const n=g.jn;if(!P[n])P[n]={t:0,w:0,nf:0,f:0,c:0,sh:{},dst:{},ori:{},ef:{},al:{}};P[n].t++;if(g.con==="Winner")P[n].w++;else if(g.con==="Error No Forzado")P[n].nf++;else if(g.con==="Error Forzado")P[n].f++;else P[n].c++;const k=SL(g);P[n].sh[k]=(P[n].sh[k]||0)+1;if(g.dst)P[n].dst[g.dst]=(P[n].dst[g.dst]||0)+1;if(g.ori)P[n].ori[g.ori]=(P[n].ori[g.ori]||0)+1;if(g.ef)P[n].ef[g.ef]=(P[n].ef[g.ef]||0)+1;if(g.al)P[n].al[g.al]=(P[n].al[g.al]||0)+1;});return P;}

/*
 * ═══════════════════════════════════════════════════════════════════════════════
 * PALETA
 * ═══════════════════════════════════════════════════════════════════════════════
 */
const S={
  bg:"#f8fafc",panel:"#ffffff",card:"#f1f5f9",border:"#e2e8f0",muted:"#64748b",green:"#059669",txt:"#0f172a",
};

const Chip=({l,on,onClick,c="#059669",sm})=>(
  <button onClick={onClick} style={{padding:sm?"5px 8px":"9px 10px",borderRadius:9,fontSize:sm?10:12,fontWeight:700,background:on?c+"18":S.panel,border:`2px solid ${on?c:S.border}`,color:on?c:S.muted,lineHeight:1.2,transition:"all .1s"}}>{l}</button>
);
const Lbl=({t})=><div style={{fontSize:9,color:S.muted,fontWeight:700,letterSpacing:".15em",textTransform:"uppercase",marginBottom:6}}>{t}</div>;

// ─── CANCHA ──────────────────────────────────────────────────────────────────
function CourtGrid({sel,onSel,rows,pfx="",accent="#059669",isRiv=true}){
  return(
    <div style={{background:"#f1f5f9",border:"2px solid #cbd5e1",borderRadius:11,overflow:"hidden",padding:"4px 4px 2px"}}>
      <div style={{display:"grid",gridTemplateColumns:"24px repeat(9,1fr)",gap:2,marginBottom:2}}>
        <div/>{LATS.map(l=><div key={l.id} style={{fontSize:6,color:SC(isRiv?l.r:l.p),textAlign:"center",fontWeight:700}}>{l.s}</div>)}
      </div>
      {rows.map(p=>(
        <div key={p.id} style={{display:"grid",gridTemplateColumns:"24px repeat(9,1fr)",gap:2,marginBottom:2}}>
          <div style={{fontSize:7,color:S.muted,display:"flex",alignItems:"center",justifyContent:"flex-end",paddingRight:2}}>{p.s}</div>
          {LATS.map(l=>{const z=pfx+p.id+"-"+l.id,on=sel===z,sd=isRiv?l.r:l.p;return(
            <div key={z} onClick={()=>onSel?.(on?null:z)} style={{background:on?accent:"rgba(0,0,0,.02)",border:`1.5px solid ${on?accent:SC(sd)+"60"}`,borderRadius:4,minHeight:22,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>
              {on&&<span style={{fontSize:8,color:"white",fontWeight:900}}>✓</span>}
            </div>
          );})}
        </div>
      ))}
    </div>
  );
}

function HeatGrid({data={},rows,pfx=""}){
  const max=Math.max(...rows.flatMap(p=>LATS.map(l=>data[pfx+p.id+"-"+l.id]||0)),1);
  return rows.map(p=>(
    <div key={p.id} style={{display:"grid",gridTemplateColumns:"24px repeat(9,1fr)",gap:2,marginBottom:2}}>
      <div style={{fontSize:7,color:S.muted,display:"flex",alignItems:"center",justifyContent:"flex-end",paddingRight:2}}>{p.s}</div>
      {LATS.map(l=>{const z=pfx+p.id+"-"+l.id,v=data[z]||0,i=v/max;return(
        <div key={z} style={{background:HC(i),border:`1px solid ${HB(i)}`,borderRadius:4,minHeight:20,display:"flex",alignItems:"center",justifyContent:"center"}}>
          {v>0&&<span style={{fontSize:9,fontWeight:700,color:i>0.5?"white":"#1e293b",fontFamily:"monospace"}}>{v}</span>}
        </div>
      );})}
    </div>
  ));
}

// ─── MARCADOR ─────────────────────────────────────────────────────────────────
function Marcador({sc,jugs}){
  const{points:pt,games:g,sets}=sc;const D=pt.A===3&&pt.B===3;
  const nA=jugs.filter(j=>j.eq==="A").map(j=>j.n.split(" ")[0]).join("/");
  const nB=jugs.filter(j=>j.eq==="B").map(j=>j.n.split(" ")[0]).join("/");
  return(
    <div style={{background:S.panel,border:`1px solid ${S.border}`,borderRadius:13,padding:"10px 12px",marginBottom:12}}>
      <div style={{fontSize:9,color:S.muted,fontWeight:700,textAlign:"center",marginBottom:7}}>🏆 MARCADOR</div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 56px 1fr",alignItems:"center",gap:6}}>
        {[{n:nA,c:"#059669",s:sets.A,gm:g.A},{n:nB,c:"#ea580c",s:sets.B,gm:g.B}].map((t,i)=>(
          <div key={i} style={{textAlign:"center"}}>
            <div style={{fontSize:10,color:t.c,fontWeight:700,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis",marginBottom:2}}>{t.n}</div>
            <div style={{display:"flex",justifyContent:"center",alignItems:"baseline",gap:10}}>
              <div><div style={{fontSize:24,color:S.txt,fontWeight:900,lineHeight:1}}>{t.s}</div><div style={{fontSize:8,color:S.muted}}>sets</div></div>
              <div><div style={{fontSize:18,color:"#2563eb",fontWeight:700,lineHeight:1}}>{t.gm}</div><div style={{fontSize:8,color:S.muted}}>gms</div></div>
            </div>
          </div>
        ))}
        <div style={{textAlign:"center"}}>
          <div style={{fontSize:18,color:"#eab308",fontWeight:900,lineHeight:1.1}}>{D?"D":PM[pt.A]||"0"}</div>
          <div style={{fontSize:9,color:"#94a3b8"}}>–</div>
          <div style={{fontSize:18,color:"#eab308",fontWeight:900,lineHeight:1.1}}>{D?"D":PM[pt.B]||"0"}</div>
        </div>
      </div>
    </div>
  );
}

// ─── PARTIDOS ─────────────────────────────────────────────────────────────────
function Partidos({matches,cur,onSel,onNew,onDel}){
  const[nom,setNom]=useState("");
  return(
    <div style={{padding:"14px 12px 80px"}}>
      <Lbl t="➕ NUEVO PARTIDO"/>
      <div style={{display:"flex",gap:8,marginBottom:18}}>
        <input value={nom} onChange={e=>setNom(e.target.value)} placeholder="Nombre del partido..."
          style={{flex:1,background:S.panel,border:`1.5px solid ${S.border}`,borderRadius:10,padding:"11px 12px",color:S.txt,fontSize:14,fontWeight:600}}/>
        <button onClick={()=>{if(nom.trim()){onNew(nom.trim());setNom("");}}} style={{background:S.green,borderRadius:10,color:"white",fontSize:14,fontWeight:900,padding:"11px 16px",border:"none"}}>▶ Crear</button>
      </div>
      <Lbl t={`📂 GUARDADOS (${matches.length})`}/>
      {matches.length===0&&<div style={{textAlign:"center",padding:"28px 0",color:S.muted,fontSize:13}}>Aún no hay partidos</div>}
      {[...matches].reverse().map(m=>(
        <div key={m.id} style={{background:cur===m.id?S.green+"12":S.panel,border:`2px solid ${cur===m.id?S.green:S.border}`,borderRadius:14,padding:"12px 14px",marginBottom:8}}>
          <div style={{display:"flex",justifyContent:"space-between",gap:8}}>
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontSize:15,color:cur===m.id?S.green:S.txt,fontWeight:800,marginBottom:2}}>{m.nom}</div>
              <div style={{fontSize:10,color:S.muted}}>{FD(m.ts)} · {m.gs?.length||0} golpes</div>
              <div style={{fontSize:10,color:S.muted,marginTop:1}}>
                {m.jugs?.filter(j=>j.eq==="A").map(j=>j.n).join("/")} vs {m.jugs?.filter(j=>j.eq==="B").map(j=>j.n).join("/")}
              </div>
              <div style={{fontSize:10,color:S.muted}}>Sets {m.sc?.sets?.A||0}–{m.sc?.sets?.B||0} · Games {m.sc?.games?.A||0}–{m.sc?.games?.B||0}</div>
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:5,flexShrink:0}}>
              {cur===m.id
                ?<div style={{background:S.green,color:"white",fontSize:10,fontWeight:900,padding:"5px 10px",borderRadius:8,textAlign:"center"}}>ACTIVO</div>
                :<button onClick={()=>onSel(m.id)} style={{background:S.green+"18",border:`1.5px solid ${S.green}`,color:S.green,fontSize:10,fontWeight:800,padding:"5px 10px",borderRadius:8}}>Retomar</button>}
              <button onClick={()=>{if(window.confirm(`¿Eliminar "${m.nom}"?`))onDel(m.id);}} style={{background:"transparent",border:"1px solid #cbd5e1",color:S.muted,fontSize:10,padding:"4px 10px",borderRadius:8}}>Borrar</button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── CONFIG ───────────────────────────────────────────────────────────────────
function Config({match,onSave}){
  const[jugs,setJugs]=useState(match?.jugs||DEF_J);
  const[nom,setNom]=useState(match?.nom||"");
  useEffect(()=>{setJugs(match?.jugs||DEF_J);setNom(match?.nom||"");},[match?.id]);
  if(!match)return<div style={{padding:40,textAlign:"center",color:S.muted}}>Creá un partido desde Partidos</div>;
  const upd=(id,f,v)=>setJugs(p=>p.map(j=>j.id===id?{...j,[f]:v}:j));
  return(
    <div style={{padding:"14px 12px 80px"}}>
      <Lbl t="Nombre del partido"/><input value={nom} onChange={e=>setNom(e.target.value)} style={{width:"100%",background:S.panel,border:`1.5px solid ${S.border}`,borderRadius:10,padding:"11px 12px",color:S.txt,fontSize:14,fontWeight:700,marginBottom:14}}/>
      {["A","B"].map(eq=>(
        <div key={eq} style={{marginBottom:14,background:S.panel,border:`1px solid ${S.border}`,borderRadius:14,padding:14}}>
          <div style={{fontSize:11,color:eq==="A"?S.green:"#ea580c",fontWeight:800,letterSpacing:".12em",textTransform:"uppercase",marginBottom:10}}>{eq==="A"?"🟢 Tu Equipo":"🟠 Rivales"}</div>
          {jugs.filter(j=>j.eq===eq).map(j=>(
            <div key={j.id} style={{marginBottom:10}}>
              <div style={{fontSize:9,color:S.muted,marginBottom:4}}>{j.l}</div>
              <input value={j.n} onChange={e=>upd(j.id,"n",e.target.value)} style={{width:"100%",background:S.card,border:`1.5px solid ${S.border}`,borderRadius:10,padding:"10px 12px",color:S.txt,fontSize:14,fontWeight:600}}/>
            </div>
          ))}
        </div>
      ))}
      <button onClick={()=>onSave({...match,nom,jugs})} style={{width:"100%",padding:"14px",background:S.green,borderRadius:14,color:"white",fontSize:15,fontWeight:900,border:"none"}}>💾 Guardar</button>
    </div>
  );
}

// ─── REGISTRO ────────────────────────────────────────────────────────────────
function Registro({match,onUpd}){
  const[jid,setJid]=useState(null);
  const[tipo,setTipo]=useState(null);
  const[s1,setS1]=useState(null);
  const[s2,setS2]=useState(null);
  const[s3,setS3]=useState(null);
  const[ef,setEf]=useState(null);
  const[al,setAl]=useState(null);
  const[ori,setOri]=useState(null);
  const[dst,setDst]=useState(null);
  const[con,setCon]=useState(null);
  const[detCon,setDetCon]=useState(null);
  const[court,setCourt]=useState(false);
  const[toast,setToast]=useState(null);
  const[pared,setPared]=useState("Sin pared");
  const[fase,setFase]=useState(null);

  const jugs=match?.jugs||DEF_J;
  const ji=jid||jugs[0]?.id;
  const jug=jugs.find(j=>j.id===ji)||jugs[0];
  const tr=tipo?GTREE[tipo]:null;
  const ss1=tr?.s1||[];
  const ss2=(tr?.s2&&s1)?tr.s2[s1]||[]:[];
  const ss3=(tr?.s3&&s2)?tr.s3[s2]||[]:[];

  const showT=(m,ok=true)=>{setToast({m,ok});setTimeout(()=>setToast(null),2000);};
  function selT(g){setTipo(tipo===g?null:g);setS1(null);setS2(null);setS3(null);}
  function selCon(c){setCon(con===c?null:c);setDetCon(null);}

  const mostrarSecuenciaNormal = fase==="resto"||fase==="otro";
  const gruposVisibles = mostrarSecuenciaNormal&&pared!=="Sin pared" ? GRUPOS_PARED : mostrarSecuenciaNormal ? GRUPOS_SIN_PARED : [];
  const mostrarSmash = mostrarSecuenciaNormal&&pared==="Sin pared";

  function elegirFase(f){
    setFase(f);
    if(f==="saque"){setTipo("Saque");setS1(null);setS2(null);setS3(null);}
    else{setTipo(null);setS1(null);setS2(null);setS3(null);}
  }

  function guardar(){
    if(!tipo){showT("Seleccioná un golpe",false);return;}
    if(!con){showT("Seleccioná la consecuencia",false);return;}
    const g={
      id:Date.now()+"_"+Math.random().toString(36).slice(2),
      ts:Date.now(),jid:ji,jn:jug?.n||"?",eq:jug?.eq||"A",
      tipo,s1,s2,s3,ef,al,ori,dst,con,detCon:detCon||null,
      pared:pared==="Sin pared"?null:pared,fase:fase||"otro"
    };
    const ngs=[...(match.gs||[]),g];
    let nsc=match.sc||INIT_SC;
    if(con==="Winner"||con==="Error No Forzado"||con==="Error Forzado"){
      const eq=con==="Winner"?jug.eq:(jug.eq==="A"?"B":"A");nsc=SAP(nsc,eq);
    }
    onUpd({...match,gs:ngs,sc:nsc});
    setTipo(null);setS1(null);setS2(null);setS3(null);setEf(null);setAl(null);
    setOri(null);setDst(null);setCon(null);setDetCon(null);setCourt(false);
    setPared("Sin pared");setFase(null);
    showT("✓ Golpe guardado");
  }

  if(!match)return<div style={{padding:40,textAlign:"center",color:S.muted}}>Seleccioná un partido</div>;
  const conActual=CONS.find(c=>c.k===con);
  const mostrarSubCon=conActual?.sub?.length>0;

  return(
    <div style={{padding:"12px 12px 80px"}}>
      {toast&&<div style={{position:"fixed",top:16,left:"50%",transform:"translateX(-50%)",background:toast.ok?"#d1fae5":"#fee2e2",border:`1px solid ${toast.ok?"#10b981":"#ef4444"}`,color:toast.ok?"#065f46":"#991b1b",padding:"8px 18px",borderRadius:12,fontSize:13,fontWeight:700,zIndex:9999}}>{toast.m}</div>}
      <Marcador sc={match.sc||INIT_SC} jugs={jugs}/>

      {/* 1. JUGADOR */}
      <Lbl t="👤 JUGADOR QUE GOLPEA"/>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6,marginBottom:12}}>
        {jugs.map(j=><button key={j.id} onClick={()=>{setJid(j.id);setFase(null);}} style={{padding:"9px 6px",borderRadius:11,fontSize:12,fontWeight:700,background:ji===j.id?(j.eq==="A"?S.green+"18":"#ffedd5"):S.panel,border:`2px solid ${ji===j.id?(j.eq==="A"?S.green:"#f97316"):S.border}`,color:ji===j.id?(j.eq==="A"?S.green:"#ea580c"):S.muted,textAlign:"center",lineHeight:1.3}}>
          <div style={{overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{j.n}</div><div style={{fontSize:9,opacity:.7}}>{j.l}</div>
        </button>)}
      </div>

      {/* 2. FASE */}
      {jid&&(
        <div style={{marginBottom:12}}>
          <Lbl t="🎯 ¿SAQUE, RESTO U OTRO GOLPE?"/>
          <div style={{display:"flex",gap:8}}>
            <button onClick={()=>elegirFase("saque")} style={{flex:1,padding:"12px",borderRadius:12,fontSize:14,fontWeight:800,background:fase==="saque"?"#fef3c7":S.panel,border:`2px solid ${fase==="saque"?"#eab308":S.border}`,color:fase==="saque"?"#b45309":S.muted}}>🎾 Saque</button>
            <button onClick={()=>elegirFase("resto")} style={{flex:1,padding:"12px",borderRadius:12,fontSize:14,fontWeight:800,background:fase==="resto"?"#dbeafe":S.panel,border:`2px solid ${fase==="resto"?"#3b82f6":S.border}`,color:fase==="resto"?"#1d4ed8":S.muted}}>↩️ Resto</button>
            <button onClick={()=>elegirFase("otro")} style={{flex:1,padding:"12px",borderRadius:12,fontSize:14,fontWeight:800,background:fase==="otro"?S.card:S.panel,border:`2px solid ${fase==="otro"?"#64748b":S.border}`,color:fase==="otro"?"#334155":S.muted}}>⏭️ Otro</button>
          </div>
        </div>
      )}

      {/* Submenú Saque */}
      {fase==="saque"&&tipo==="Saque"&&ss1.length>0&&(
        <div style={{background:"#fffbeb",border:"1.5px solid #fcd34d",borderRadius:12,padding:"10px",marginBottom:8}}>
          <div style={{fontSize:9,color:"#b45309",fontWeight:800,textTransform:"uppercase",marginBottom:7}}>⚡ SERVICIO</div>
          <div style={{display:"flex",flexWrap:"wrap",gap:5}}>
            {ss1.map(s=><Chip key={s} l={s} on={s1===s} onClick={()=>setS1(s1===s?null:s)} c="#eab308" sm/>)}
          </div>
        </div>
      )}

      {/* Secuencia Resto / Otro */}
      {mostrarSecuenciaNormal&&(
        <>
          <Lbl t="🧱 ¿VIENE DE PARED?"/>
          <div style={{display:"flex",flexWrap:"wrap",gap:5,marginBottom:14}}>
            {PAREDES_OPCIONES.map(op=><Chip key={op} l={op} on={pared===op} onClick={()=>{setPared(op);setTipo(null);setS1(null);}} c={op==="Sin pared"?S.green:"#ea580c"} sm/>)}
          </div>
          <Lbl t="🎾 TIPO DE GOLPE"/>
          {gruposVisibles.map(gr=>(
            <div key={gr.label} style={{marginBottom:9}}>
              <div style={{fontSize:8,color:gr.c,fontWeight:800,letterSpacing:".12em",textTransform:"uppercase",marginBottom:4}}>{gr.label}</div>
              <div style={{display:"flex",flexWrap:"wrap",gap:5}}>{gr.keys.map(g=><Chip key={g} l={g} on={tipo===g} onClick={()=>selT(g)} c={GTREE[g]?.c||S.green}/>)}</div>
            </div>
          ))}
          {mostrarSmash&&(
            <div style={{marginBottom:9}}>
              <div style={{fontSize:8,color:GRUPO_SMASH.c,fontWeight:800,letterSpacing:".12em",textTransform:"uppercase",marginBottom:4}}>{GRUPO_SMASH.label}</div>
              <div style={{display:"flex",flexWrap:"wrap",gap:5}}>{GRUPO_SMASH.keys.map(g=><Chip key={g} l={g} on={tipo===g} onClick={()=>selT(g)} c={GTREE[g]?.c||S.green}/>)}</div>
            </div>
          )}
        </>
      )}

      {/* Submenú golpes (excepto Saque) */}
      {tipo&&fase!=="saque"&&ss1.length>0&&(
        <div style={{background:S.card,border:`1.5px solid ${S.border}`,borderRadius:12,padding:"10px",marginBottom:8}}>
          <div style={{fontSize:8,color:tr?.c||S.green,fontWeight:800,letterSpacing:".12em",textTransform:"uppercase",marginBottom:7}}>
            ↳ {(tipo==="Salida de Pared"||tipo==="Bajada de Pared")?"TIPO DE PARED":"VARIANTE"}
          </div>
          <div style={{display:"flex",flexWrap:"wrap",gap:5}}>{ss1.map(s=><Chip key={s} l={s} on={s1===s} onClick={()=>{setS1(s1===s?null:s);setS2(null);setS3(null);}} c={tr?.c||S.green}/>)}</div>

          {s1&&ss2.length>0&&(
            <div style={{marginTop:8,paddingTop:8,borderTop:`1px solid ${S.border}`}}>
              <div style={{fontSize:8,color:"#2563eb",fontWeight:800,textTransform:"uppercase",marginBottom:6}}>
                ↳ {(tipo==="Salida de Pared"||tipo==="Bajada de Pared")?"GOLPE DE SALIDA":"LADO"}
              </div>
              <div style={{display:"flex",flexWrap:"wrap",gap:5}}>{ss2.map(s=><Chip key={s} l={s} on={s2===s} onClick={()=>{setS2(s2===s?null:s);setS3(null);}} c="#2563eb" sm/>)}</div>
            </div>
          )}

          {s2&&ss3.length>0&&(
            <div style={{marginTop:8,paddingTop:8,borderTop:`1px solid ${S.border}`}}>
              <div style={{fontSize:8,color:"#8b5cf6",fontWeight:800,textTransform:"uppercase",marginBottom:6}}>↳ LADO</div>
              <div style={{display:"flex",flexWrap:"wrap",gap:5}}>{ss3.map(s=><Chip key={s} l={s} on={s3===s} onClick={()=>setS3(s3===s?null:s)} c="#8b5cf6" sm/>)}</div>
            </div>
          )}
        </div>
      )}

      {/* Efecto, Altura, Cancha, Consecuencia */}
      {tipo&&(
        <>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:12}}>
            <div><Lbl t="🌀 EFECTO"/><div style={{display:"flex",flexDirection:"column",gap:4}}>{["Plano","Cortado","Liftado"].map(e=><Chip key={e} l={e} on={ef===e} onClick={()=>setEf(ef===e?null:e)} c="#eab308" sm/>)}</div></div>
            <div><Lbl t="↕️ ALTURA"/><div style={{display:"flex",flexDirection:"column",gap:4}}>{["Alta","Media","Baja"].map(a=><Chip key={a} l={a} on={al===a} onClick={()=>setAl(al===a?null:a)} c="#8b5cf6" sm/>)}</div></div>
          </div>

          <button onClick={()=>setCourt(!court)} style={{width:"100%",marginBottom:court?8:12,padding:"10px 14px",background:court?S.green+"18":S.panel,border:`2px solid ${court?S.green:S.border}`,borderRadius:12,color:court?S.green:S.muted,fontSize:12,fontWeight:700,display:"flex",justifyContent:"space-between"}}>
            <span>🗺️ CANCHA {ori?"· Ori ✓":""}{dst?"· Dst ✓":""}</span><span>{court?"▲":"▼"}</span>
          </button>
          {court&&<div style={{display:"flex",flexDirection:"column",gap:8,marginBottom:12}}>
            <CourtGrid sel={ori} onSel={setOri} rows={PROFO} pfx="ORI-" accent={S.green} isRiv={false}/>
            <CourtGrid sel={dst} onSel={setDst} rows={PROFS} accent="#ea580c" isRiv={true}/>
          </div>}

          <Lbl t="⚡ CONSECUENCIA"/>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:7,marginBottom:10}}>
            {CONS.map(x=><button key={x.k} onClick={()=>selCon(x.k)} style={{padding:"12px 6px",borderRadius:13,fontSize:13,fontWeight:800,background:con===x.k?x.bg:S.panel,border:`2px solid ${con===x.k?x.b:S.border}`,color:con===x.k?x.c:S.muted,textAlign:"center",lineHeight:1.3}}>{x.l}</button>)}
          </div>
          {mostrarSubCon&&(
            <div style={{background:conActual.bg,border:`1.5px solid ${conActual.b}`,borderRadius:12,padding:"10px",marginBottom:12}}>
              <div style={{fontSize:8,color:conActual.c,fontWeight:800,letterSpacing:".12em",textTransform:"uppercase",marginBottom:7}}>↳ DETALLE</div>
              <div style={{display:"flex",flexWrap:"wrap",gap:5}}>{conActual.sub.map(d=><Chip key={d} l={d} on={detCon===d} onClick={()=>setDetCon(detCon===d?null:d)} c={conActual.c} sm/>)}</div>
            </div>
          )}

          <button onClick={guardar} style={{width:"100%",padding:"15px",background:tipo&&con?S.green:S.card,border:`2px solid ${tipo&&con?S.green:S.border}`,borderRadius:14,color:tipo&&con?"white":S.muted,fontSize:16,fontWeight:900}}>✓ GUARDAR GOLPE</button>
        </>
      )}
    </div>
  );
}

// ─── STATS ───────────────────────────────────────────────────────────────────
function Stats({match}){
  const gs=match?.gs||[];
  const st=useMemo(()=>calcSt(gs),[gs]);
  const ns=Object.keys(st);
  const[sel,setSel]=useState(null);
  const ac=sel||(ns[0]||null);
  const ps=ac?st[ac]:null;
  if(!match)return<div style={{padding:30,textAlign:"center",color:S.muted}}>Seleccioná un partido</div>;
  if(!gs.length)return<div style={{padding:30,textAlign:"center",color:S.muted}}>Sin golpes registrados</div>;
  const bd=ps?Object.entries(ps.sh).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([k,v])=>({name:k.split("·")[0].trim(),v})):[];
  const CL=["#059669","#2563eb","#ea580c","#8b5cf6","#eab308","#ef4444","#10b981","#f97316"];
  return(
    <div style={{padding:"14px 12px 80px"}}>
      <Lbl t={`📊 ${gs.length} golpes · ${match.nom}`}/>
      <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:12}}>{ns.map(n=><button key={n} onClick={()=>setSel(n)} style={{padding:"7px 12px",borderRadius:9,fontSize:11,fontWeight:700,background:ac===n?S.green+"18":S.panel,border:`2px solid ${ac===n?S.green:S.border}`,color:ac===n?S.green:S.muted}}>{n}</button>)}</div>
      {ps&&<>
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:6,marginBottom:12}}>
          {[{l:"Total",v:ps.t,c:"#2563eb"},{l:"Winners",v:ps.w,c:"#059669"},{l:"Err.NF",v:ps.nf,c:"#dc2626"},{l:"Err.F",v:ps.f,c:"#ea580c"}].map(({l,v,c})=>(
            <div key={l} style={{background:S.panel,border:`1px solid ${S.border}`,borderRadius:11,padding:"10px 4px",textAlign:"center"}}>
              <div style={{fontSize:22,color:c,fontWeight:900,lineHeight:1}}>{v}</div><div style={{fontSize:9,color:S.muted,marginTop:2}}>{l}</div>
            </div>
          ))}
        </div>
        <div style={{background:S.panel,border:`1px solid ${S.border}`,borderRadius:12,padding:12,marginBottom:12}}>
          <Lbl t="Resultados"/>
          {[{n:"Winners",v:ps.w,c:"#059669"},{n:"Err. No Forzado",v:ps.nf,c:"#dc2626"},{n:"Err. Forzado",v:ps.f,c:"#ea580c"},{n:"Continúa",v:ps.c,c:"#2563eb"}].map(d=>(
            <div key={d.n} style={{marginBottom:7}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:3}}><span style={{fontSize:11,color:S.txt}}>{d.n}</span><span style={{fontSize:11,color:d.c,fontWeight:700}}>{d.v} ({PCT(d.v,ps.t)}%)</span></div>
              <div style={{height:6,background:S.card,borderRadius:4,overflow:"hidden"}}><div style={{height:"100%",width:PCT(d.v,ps.t)+"%",background:d.c,borderRadius:4}}/></div>
            </div>
          ))}
        </div>
        {bd.length>0&&<div style={{background:S.panel,border:`1px solid ${S.border}`,borderRadius:12,padding:12,marginBottom:12}}>
          <Lbl t="Golpes más usados"/>
          <ResponsiveContainer width="100%" height={110}>
            <BarChart data={bd} margin={{top:0,right:0,left:-22,bottom:0}}>
              <XAxis dataKey="name" tick={{fontSize:8,fill:S.muted}} axisLine={false} tickLine={false}/>
              <YAxis tick={{fontSize:8,fill:S.muted}} axisLine={false} tickLine={false}/>
              <Tooltip contentStyle={{background:S.panel,border:`1px solid ${S.border}`,borderRadius:8,fontSize:11}}/>
              <Bar dataKey="v" radius={[4,4,0,0]}>{bd.map((_,i)=><Cell key={i} fill={CL[i%8]}/>)}</Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>}
        <div style={{background:S.panel,border:`1px solid ${S.border}`,borderRadius:13,overflow:"hidden",marginBottom:12}}>
          <div style={{padding:"5px 10px",background:S.card}}><span style={{fontSize:9,color:S.green,fontWeight:800}}>🗺️ Mapa · {ac}</span></div>
          <div style={{padding:"7px 5px"}}>
            <div style={{fontSize:8,color:"#2563eb",fontWeight:800,marginBottom:3}}>▲ DESTINO</div>
            <HeatGrid data={ps.dst} rows={PROFS}/>
            <div style={{margin:"4px 0",height:4,background:"linear-gradient(90deg,transparent,#2563eb,transparent)",borderRadius:2}}/>
            <div style={{fontSize:8,color:S.green,fontWeight:800,marginBottom:3}}>▼ ORIGEN</div>
            <HeatGrid data={ps.ori} rows={PROFO} pfx="ORI-"/>
          </div>
        </div>
      </>}
    </div>
  );
}

// ─── LOG ─────────────────────────────────────────────────────────────────────
function Log({match,onUpd}){
  const gs=match?.gs||[];
  const CC={"Winner":"#059669","Error No Forzado":"#dc2626","Error Forzado":"#ea580c","Continúa":"#2563eb"};
  if(!match)return<div style={{padding:30,textAlign:"center",color:S.muted}}>Seleccioná un partido</div>;
  return(
    <div style={{padding:"14px 12px 80px"}}>
      <Lbl t={`📋 ${gs.length} golpes · ${match.nom}`}/>
      {!gs.length&&<div style={{textAlign:"center",padding:28,color:S.muted}}>Sin golpes</div>}
      {[...gs].reverse().map(g=>(
        <div key={g.id} style={{background:S.panel,borderLeft:`3px solid ${CC[g.con]||S.muted}`,border:`1px solid ${S.border}`,borderRadius:10,padding:"9px 11px",marginBottom:6,display:"flex",justifyContent:"space-between"}}>
          <div>
            <div style={{fontSize:13,color:S.txt,fontWeight:700}}>
              {g.fase==="saque"?"🎾 ":g.fase==="resto"?"↩️ ":""}{SL(g)}
            </div>
            <div style={{fontSize:10,color:S.muted}}>{g.jn}{g.ef?` · ${g.ef}`:""}{g.al?` · ${g.al}`:""}{g.detCon?` · ${g.detCon}`:""}</div>
            {(g.ori||g.dst)&&<div style={{fontSize:10,color:S.muted}}>{g.ori&&`📍${ZN(g.ori)}`}{g.dst&&` → 🎯${ZN(g.dst)}`}</div>}
          </div>
          <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:5}}>
            <span style={{fontSize:11,color:CC[g.con]||S.muted,fontWeight:700}}>{g.con}</span>
            <button onClick={()=>onUpd({...match,gs:gs.filter(x=>x.id!==g.id)})} style={{background:"transparent",border:"1px solid #cbd5e1",color:S.muted,fontSize:10,padding:"2px 7px",borderRadius:6}}>✕</button>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── APP ─────────────────────────────────────────────────────────────────────
export default function App(){
  const[ms,setMs]=useState([]);const[cur,setCur]=useState(null);const[tab,setTab]=useState("partidos");const[rdy,setRdy]=useState(false);
  useEffect(()=>{(async()=>{const m=await db.get("pt_ms");const c=await db.get("pt_cur");if(m?.length){setMs(m);setCur(c||m[m.length-1].id);setTab("registro");}setRdy(true);})();},[]);
  const match=useMemo(()=>ms.find(m=>m.id===cur)||null,[ms,cur]);
  async function save(nm,nc){setMs(nm);if(nc!==undefined)setCur(nc);await db.set("pt_ms",nm);if(nc!==undefined)await db.set("pt_cur",nc);}
  function onNew(nom){const id="m"+Date.now();const m={id,nom,ts:Date.now(),jugs:JSON.parse(JSON.stringify(DEF_J)),gs:[],sc:JSON.parse(JSON.stringify(INIT_SC))};save([...ms,m],id);setTab("config");}
  function onSel(id){save(ms,id);setTab("registro");}
  function onDel(id){const nm=ms.filter(m=>m.id!==id);save(nm,id===cur?(nm[nm.length-1]?.id||null):cur);}
  function onUpd(upd){save(ms.map(m=>m.id===upd.id?upd:m),undefined);}
  function onSaveCfg(upd){onUpd(upd);setTab("registro");}
  const NAV=[{id:"partidos",ic:"📂",lb:"Partidos"},{id:"config",ic:"⚙️",lb:"Config"},{id:"registro",ic:"🎾",lb:"Registrar"},{id:"stats",ic:"📊",lb:"Stats"},{id:"log",ic:"📋",lb:"Log"}];
  if(!rdy)return<div style={{background:S.bg,minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",color:S.green,fontSize:14}}>Cargando...</div>;
  return(
    <div style={{background:S.bg,minHeight:"100vh",color:S.txt,fontFamily:"system-ui,sans-serif",paddingBottom:64}}>
      <div style={{background:S.panel,borderBottom:`1px solid ${S.border}`,padding:"10px 14px",display:"flex",alignItems:"center",gap:10}}>
        <span>🎾</span>
        <div style={{flex:1}}>
          <div style={{fontSize:15,fontWeight:900,color:S.green}}>PADEL TRACKER</div>
          {match&&<div style={{fontSize:9,color:S.muted}}>{match.nom} · {match.gs?.length||0} golpes</div>}
        </div>
        {match&&<div style={{fontSize:10,color:"#2563eb",fontWeight:700}}>{match.sc?.sets?.A||0}–{match.sc?.sets?.B||0}</div>}
      </div>
      <div style={{overflowY:"auto",maxHeight:"calc(100vh - 114px)"}}>
        {tab==="partidos"&&<Partidos matches={ms} cur={cur} onSel={onSel} onNew={onNew} onDel={onDel}/>}
        {tab==="config"  &&<Config match={match} onSave={onSaveCfg}/>}
        {tab==="registro"&&<Registro match={match} onUpd={onUpd}/>}
        {tab==="stats"   &&<Stats match={match}/>}
        {tab==="log"     &&<Log match={match} onUpd={onUpd}/>}
      </div>
      <div style={{position:"fixed",bottom:0,left:0,right:0,background:S.panel,borderTop:`1px solid ${S.border}`,display:"flex",zIndex:999}}>
        {NAV.map(n=><button key={n.id} onClick={()=>setTab(n.id)} style={{flex:1,padding:"9px 0 7px",textAlign:"center",background:tab===n.id?S.card:"transparent",borderTop:`2px solid ${tab===n.id?S.green:"transparent"}`,color:tab===n.id?S.green:S.muted,border:"none"}}>
          <div style={{fontSize:16}}>{n.ic}</div><div style={{fontSize:8,fontWeight:700}}>{n.lb}</div>
        </button>)}
      </div>
    </div>
  );
}
